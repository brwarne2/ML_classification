# # load CSV using csv
# import csv
# import numpy
# filename = 'pima-indians-diabetes.data.csv'
# raw_data = open(filename, 'rt')
# reader = csv.reader(raw_data, delimiter=',', quoting=csv.QUOTE_NONE)
# x = list(reader)
# data = numpy.array(x).astype('float')
# print(data.shape)
#
# # load CSV using numpy
# from numpy import loadtxt
# filename = 'pima-indians-diabetes.data.csv'
# raw_data = open(filename, 'rt')
# data = loadtxt(raw_data, delimiter=",")
# print(data.shape)
#
# # load CSV using Pandas (preferred method)
# from pandas import read_csv
# filename = 'pima-indians-diabetes.data.csv'
# names = ['preg', 'plas', 'pres', 'skin', 'test', 'mass', 'pedi', 'age', 'class'] data = read_csv(filename, names=names)
# print(data.shape)
# # Load CSV using Pandas from URL
# from pandas import read_csv
# url = 'https://goo.gl/bDdBiA'
# names = ['preg', 'plas', 'pres', 'skin', 'test', 'mass', 'pedi', 'age', 'class'] data = read_csv(url, names=names)
# print(data.shape)

# peek at the data
# view first 20 rows
from pandas import read_csv
filename = "pima-indians-diabetes.data.csv"
names = ['preg', 'plas', 'pres', 'skin', 'test', 'mass', 'pedi', 'age', 'class']
data = read_csv(filename, names=names)
peek = data.head(20)
# print(peek)
# peek dimensions of data
shape = data.shape
# print(shape) # 768 rows 9 cols
# peek data types
types = data.dtypes
# print(types)
from pandas import set_option
set_option('display.width', 100)
set_option('precision', 3)
description = data.describe()
# print(description)

# get distributions
class_counts = data.groupby('class').size()
# print(class_counts) # 0 - no onset diabetes 1 - onset diabetes

# get correlations
# correlations = data.corr(method='pearson')
# print(correlations)

# Load CSV using Pandas
from pandas import read_csv
filename = 'pima-indians-diabetes.data.csv'
names = ['preg', 'plas', 'pres', 'skin', 'test', 'mass', 'pedi', 'age', 'class']
data = read_csv(filename, names=names)
# print(data.shape)

# Correlations between attributes
set_option('display.width', 100)
set_option('precision', 3)
correlations = data.corr(method='pearson')
# print(correlations)
skew = data.skew()
# print(skew)

# Visualize
from matplotlib import pyplot
# data.hist()
# pyplot.show()
# density plot
# data.plot(kind='density', subplots=True, layout=(3,3), sharex=False)
# box plot
# data.plot(kind='box', subplots=True, layout=(3,3), sharex=False, sharey=False)
# pyplot.show()
import numpy
# correlation matrix plot
correlations = data.corr()
# plot correlation matrix
# fig = pyplot.figure()
# ax = fig.add_subplot(111)
# cax = ax.matshow(correlations, vmin=-1, vmax=1)
# fig.colorbar(cax)
# ticks = numpy.arange(0,9,1)
# ax.set_xticks(ticks)
# ax.set_yticks(ticks)
# ax.set_xticklabels(names)
# ax.set_yticklabels(names)
# pyplot.show()

# scatter plot matrix
# from pandas.plotting import scatter_matrix
# data = read_csv(filename, names=names)
# scatter_matrix(data)
# pyplot.show()

# Rescale Data (useful for k-Nearest Neighbors)
from numpy import set_printoptions
from sklearn.preprocessing import MinMaxScaler
dataframe = read_csv(filename, names=names)
array = dataframe.values
# separate array into input and output components
X = array[:,0:8]
Y = array[:,8]
scaler = MinMaxScaler(feature_range=(0, 1))
rescaledX = scaler.fit_transform(X)
# summarize transformed data
set_printoptions(precision=3)
# print(rescaledX[0:5,:])

# Standardize Data (transforms attributes with a Guassian distribution and differing st. devs.
# and means to a standard Gaussian distribution with a mean of 0 and st.dev. of 1
from sklearn.preprocessing import StandardScaler
from pandas import read_csv
from numpy import set_printoptions
# separate array into input and output components
X = array[:,0:8]
Y = array[:,8]
scaler = StandardScaler().fit(X)
rescaledX = scaler.transform(X)
# summarize transformed data
set_printoptions(precision=3)
# print(rescaledX[0:5,:])

# Normalize Data (rescaling each observation to have a length of 1 - useful for sparse datasets)
# also useful when using algorithms that weight input values such as neural networks
# and useful for algorithms that use distance measures such as k-Nearest Neighbors
from sklearn.preprocessing import Normalizer
scaler = Normalizer().fit(X)
normalizedX = scaler.transform(X)
# summarize transformed data
set_printoptions(precision=3)
# print(normalizedX[0:5,:])

# Binarize data - thresholding can be useful when you want to transform probabilities to crisp values
from sklearn.preprocessing import Binarizer
binarizer = Binarizer(threshold=0.0).fit(X)
binaryX = binarizer.transform(X)
# summarize transformed data
# set_printoptions(precision=3)
# print(binaryX[0:5,:])

# Feature Selection 1) reduces overfitting 2) improves accuracy 3) reduces training time
# A) Univariate Selection - selecting features that have strongest relationship to the output variable
from numpy import set_printoptions
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_classif
# feature extraction
test = SelectKBest(score_func=f_classif, k=4)
fit = test.fit(X, Y)
# summarize scores
set_printoptions(precision=3)
# print(fit.scores_)
features = fit.transform(X)
# summarize selected features
# print(features[0:5,:]) # indexes 0 (preg), 1 (plas), 5 (mass), and 7 (age) have highest 4 scores

# B) Recursive Feature Elimination
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
# feature extraction
model = LogisticRegression(solver='liblinear')
rfe = RFE(model, 3)
fit = rfe.fit(X, Y)
# print("Num Features: %d" % fit.n_features_)
# print("Selected Features: %s" % fit.support_)
# print("Feature Ranking: %s" % fit.ranking_)
# top 3 features: preg, mass, pedi

# C) Principal Component Analysis
from sklearn.decomposition import PCA
# feature extraction
pca = PCA(n_components=3)
fit = pca.fit(X)
# summarize components
# print("Explained Variance: %s" % fit.explained_variance_ratio_)
# print(fit.components_)

# D) Feature Importance - Random Forest and Extra Trees and estimate the importance of features
from sklearn.ensemble import ExtraTreesClassifier
# feature extraction
model = ExtraTreesClassifier(n_estimators=100)
model.fit(X, Y)
# print(model.feature_importances_)

# Evaluation of algorithms / spliting into testing and training
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
test_size = 0.33
seed = 7
# X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=test_size,
# random_state=seed)
# model = LogisticRegression(solver='liblinear')
# model.fit(X_train, Y_train)
# result = model.score(X_test, Y_test)
# print("Accuracy: %.3f%%" % (result*100.0))

# A) K-fold Cross-Validation - estimate performance with less variance than a single test-train split (k=3,5,or 10)
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
# kfold = KFold(n_splits=10, random_state=7, shuffle=True)
# model = LogisticRegression(solver='liblinear')
# results = cross_val_score(model, X, Y, cv=kfold)
# print("Accuracy: %.3f%% (%.3f%%)" % (results.mean()*100.0, results.std()*100.0))

# B) Leave One Out Cross-Validation - more computationally expensive than k-fold
from sklearn.model_selection import LeaveOneOut
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
# loocv = LeaveOneOut()
# model = LogisticRegression(solver='liblinear')
# results = cross_val_score(model, X, Y, cv=loocv)
# print("Accuracy: %.3f%% (%.3f%%)" % (results.mean()*100.0, results.std()*100.0))

# C) Repeated Random Test-Train Splits
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
# n_splits = 10
# test_size = 0.33
# seed = 7
# kfold = ShuffleSplit(n_splits=n_splits, test_size=test_size, random_state=seed)
# model = LogisticRegression(solver='liblinear')
# results = cross_val_score(model, X, Y, cv=kfold)
# print("Accuracy: %.3f%% (%.3f%%)" % (results.mean()*100.0, results.std()*100.0))

# when in doubt, use 10-fold cross-validation

# Classification metrics
# A) Classification Accuracy: correct predictions / all predictions
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
# kfold = KFold(n_splits=10, random_state=7, shuffle=True)
# model = LogisticRegression(solver='liblinear')
# scoring = 'accuracy'
# results = cross_val_score(model, X, Y, cv=kfold, scoring=scoring)
# print("Accuracy: %.3f (%.3f)" % (results.mean(), results.std()))

# B) Logistic Loss:
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
# kfold = KFold(n_splits=10, random_state=7, shuffle=True)
# model = LogisticRegression(solver='liblinear')
# scoring = 'neg_log_loss'
# results = cross_val_score(model, X, Y, cv=kfold, scoring=scoring)
# print("Logloss: %.3f (%.3f)" % (results.mean(), results.std()))

# C) Area Under ROC Curve (ROC AUC) - used for binary classification problems (from 0.5 - 1.0)
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
# kfold = KFold(n_splits=10, random_state=7, shuffle=True)
# model = LogisticRegression(solver='liblinear')
# scoring = 'roc_auc'
# results = cross_val_score(model, X, Y, cv=kfold, scoring=scoring)
# print("AUC: %.3f (%.3f)" % (results.mean(), results.std()))

# D) Confusion Matrix
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
# test_size = 0.33
# seed = 7
# X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=test_size,
# random_state=seed)
# model = LogisticRegression(solver='liblinear')
# model.fit(X_train, Y_train)
# predicted = model.predict(X_test)
# matrix = confusion_matrix(Y_test, predicted)
# print(matrix)

# E) Classification Report - displays precision, recall, F1-score and support for each class
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
# test_size = 0.33
# seed = 7
# X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=test_size,
# random_state=seed)
# model = LogisticRegression(solver='liblinear')
# model.fit(X_train, Y_train)
# predicted = model.predict(X_test)
# report = classification_report(Y_test, predicted)
# print(report)

# Spot-checking algorithms (seeing which works best on your dataset)
# A) Logistic Regression - assumes Gaussian distribution for numeric input variables
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
# kfold = KFold(n_splits=10, random_state=7, shuffle=True)
# model = LogisticRegression(solver='liblinear')
# results = cross_val_score(model, X, Y, cv=kfold)
# print(results.mean())

# B) Linear Discriminant Analysis
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
# kfold = KFold(n_splits=10, random_state=7, shuffle=True)
# model = LinearDiscriminantAnalysis()
# results = cross_val_score(model, X, Y, cv=kfold)
# print(results.mean())

# C) k-Nearest Neighbors
from sklearn.neighbors import KNeighborsClassifier
# kfold = KFold(n_splits=10, random_state=7, shuffle=True)
# model = KNeighborsClassifier()
# results = cross_val_score(model, X, Y, cv=kfold)
# print(results.mean())

# D) Naive Bayes
from sklearn.naive_bayes import GaussianNB
# kfold = KFold(n_splits=10, random_state=7, shuffle=True)
# model = GaussianNB()
# results = cross_val_score(model, X, Y, cv=kfold)
# print(results.mean())

# E) Classification and Regression Trees (CART or decision trees)
from sklearn.tree import DecisionTreeClassifier
# kfold = KFold(n_splits=10, random_state=7, shuffle=True)
# model = DecisionTreeClassifier()
# results = cross_val_score(model, X, Y, cv=kfold)
# print(results.mean())

# F) Support Vector Machines - can use different kernel functions via the kernel parameter.
# Radial Basis Function is used by default
# from sklearn.svm import SVC
# kfold = KFold(n_splits=10, random_state=7, shuffle=True)
# model = SVC()
# results = cross_val_score(model, X, Y, cv=kfold)
# print(results.mean())




